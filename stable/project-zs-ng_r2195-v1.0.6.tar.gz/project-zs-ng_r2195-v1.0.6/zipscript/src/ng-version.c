#include "ng-version.h"

const char* ng_version(void) { const char *NG_Version = "v1.0.6-r2195"; return NG_Version; }
