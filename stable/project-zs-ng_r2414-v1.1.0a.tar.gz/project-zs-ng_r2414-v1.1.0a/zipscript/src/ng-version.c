#include "ng-version.h"

const char* ng_version = "v1.1.0a-r2414";
