#include "ng-version.h"

const char* ng_version(void) { const char *NG_Version = "v1.0.8-r2252"; return NG_Version; }
