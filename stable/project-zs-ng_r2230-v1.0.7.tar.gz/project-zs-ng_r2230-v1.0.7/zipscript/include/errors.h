#define		SFV_FIRST			"CRC-Check: SFV first!"
#define		ZERO_CRC			"CRC-Check: ERROR!"
#define		BAD_CRC				"CRC-Check: BAD!"
#define		NOT_IN_SFV			"CRC-Check: Not in sfv!"
#define		EMPTY_SFV			"SFV-file: BAD!"
#define		DOUBLE_SFV			"SFV-file: DUPE!"
#define		BAD_ZIP				"ZiP-Integrity: BAD!"
#define		EMPTY_FILE			"0byte-file: Not allowed!"
#define		BANNED_FILE			"Banned file: Not allowed!"
#define		UNKNOWN_FILE			"%s-file: Not allowed!"				/* %s = file extension	 */
#define 	BANNED_GENRE			"%s is banned here!"				/* %s = genre		 */
#define		BANNED_YEAR			"Releases from %s are not allowed here!"	/* %s = year		 */
#define		BANNED_BITRATE			"%s kbit codec is not allowed here!"		/* %s = bitrate		 */
#define		DUPE_NFO			"NFO-File: DUPE!"
#define		ZIP_NFO				"NFO-File: Not allowed here!"
#define		SPEEDTEST			"BW: %.1fMiB (%.1fMB) @ %.2fMbps (%.2fMB/s)."

