#include "ng-version.h"

const char* ng_version = "v1.0.9b-r2297";
