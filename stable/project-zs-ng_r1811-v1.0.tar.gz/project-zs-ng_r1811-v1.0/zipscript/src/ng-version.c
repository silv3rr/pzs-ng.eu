#include "ng-version.h"

const char* ng_version(void) { const char* NG_Version = "1.0.0.1811"; return NG_Version; }
