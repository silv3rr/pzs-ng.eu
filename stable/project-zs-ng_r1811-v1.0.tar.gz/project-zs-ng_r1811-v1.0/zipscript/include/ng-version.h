#ifndef _NG_VERSION_H_
#define _NG_VERSION_H_

extern const char *ng_version(void);

#endif

