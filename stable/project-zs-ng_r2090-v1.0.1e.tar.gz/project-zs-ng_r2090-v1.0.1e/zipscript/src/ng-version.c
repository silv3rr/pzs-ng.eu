#include "ng-version.h"

const char* ng_version(void) { const char *NG_Version = "v1.0.1e-r2090"; return NG_Version; }
