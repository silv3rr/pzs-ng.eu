#include "ng-version.h"

const char* ng_version = "v1.2.0-r2500";
