#include "ng-version.h"

const char* ng_version = "r2503";
